import math

def triangle(x_list,y_list):
   
    x_list=[300,400,300,300]
    y_list=[100,100,200,100]
       
    return x_list,y_list

def hexagon(x_list,y_list):
   
    x_list=[200,175,125,100,125,175,200]
    y_list=[150,200,200,150,100,100,150]
       
    return x_list,y_list
def rectangle(x_list,y_list):
   
    x_list=[200.400,400,200,200]
    y_list=[300,300,400,400,300]
       
    return x_list,y_list

