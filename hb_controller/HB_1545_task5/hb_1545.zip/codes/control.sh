#!/bin/bash

# Run Python script 1
./control_mod_bot1.py &

# Run Python script 2
./control_mod_bot2.py &

# Run Python script 3
./control_mod_bot3.py &



